package PCode.Operator;

// 定义逻辑操作枚举
public enum LogicalOperator {
    AND,    // 逻辑与
    OR,     // 逻辑或
    NOT     // 逻辑非

}
