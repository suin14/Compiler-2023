package PCode.Operator;

// 定义输入/输出操作枚举
public enum IOOperator {
    GETINT, // 获取整数输入
    PRINT   // 输出打印

}
