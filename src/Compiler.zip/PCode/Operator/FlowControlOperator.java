package PCode.Operator;

// 定义流控制操作枚举
public enum FlowControlOperator {
    JZ,     // 跳转为零
    JNZ,    // 跳转非零
    JMP     // 无条件跳转

}
