package PCode;

public record Func(int index, int args) {
}
