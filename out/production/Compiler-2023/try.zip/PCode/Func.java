package PCode;

/**
 * @param index 参数索引
 * @param args  参数数量
 */
public record Func(int index, int args) {
}
